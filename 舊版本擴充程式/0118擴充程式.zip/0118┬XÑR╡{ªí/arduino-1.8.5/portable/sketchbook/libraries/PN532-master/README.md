# Adafruit PN532 with support to Linkit 7697
## Purpose
Making Adafruit PN532 also support Linkit 7697 chip
### Features
- This project facilitate Adafruit PN532 compatitable to Linkit 7697 as well.
- This project is remodified from the original [Adafruit PN532](https://github.com/adafruit/Adafruit-PN532), therefore it also supports all chips supported by the origanal one.
